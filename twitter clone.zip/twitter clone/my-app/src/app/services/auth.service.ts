import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  user: User
  users: User[]

  constructor(public http: HttpClient) {
    this.user = new User()
    this.users = []
  }

  getUsers() {
    return this.http.get<User[]>('/assets/user_data.json')
  }

}
