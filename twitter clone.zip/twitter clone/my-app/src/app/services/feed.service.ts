import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tweet } from '../model/tweet';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class FeedService {

  myTweets: Tweet[]
  sortedTweets: Tweet[]
  likedTweetId: number[]
  retweetedTweetId: number[]
  allTweets: Tweet[]
  likedTweets: Tweet[]
  reTweets: Tweet[]

  constructor(public http: HttpClient, public auth: AuthService) {
    this.myTweets = []
    this.allTweets = []
    this.sortedTweets = []
    this.likedTweets = []
    this.reTweets = []
    this.likedTweetId = [9, 46, 23, 78, 66]
    this.retweetedTweetId = [12, 45, 33, 98, 56]
  }

  getAllTweets() {
    this.http.get<Tweet[]>('/assets/tweet_data.json').subscribe(res => {
      this.allTweets = res
      this.sortedTweets = this.allTweets.sort((a, b) => (a.user.name > b.user.name) ? 1 : ((b.user.name > a.user.name) ? -1 : 0))
      this.likedTweetId.forEach(t => {
        this.likedTweets.push(this.allTweets[t])
      })
      this.retweetedTweetId.forEach(t => {
        this.reTweets.push(this.allTweets[t])
      })
    })
  }

}