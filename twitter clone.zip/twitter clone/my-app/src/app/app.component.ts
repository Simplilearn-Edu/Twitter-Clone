import { Component } from '@angular/core';
import { AuthService } from './services/auth.service';
import { FeedService } from './services/feed.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(public feed: FeedService, public auth: AuthService) {

  }

  ngOnInit() {
    this.feed.getAllTweets()
  }


}
