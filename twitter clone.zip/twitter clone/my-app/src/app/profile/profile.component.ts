import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { AuthService } from '../services/auth.service';
import { FeedService } from '../services/feed.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: User
  constructor(public auth: AuthService, public feed: FeedService) {
    this.user = new User()
  }

  ngOnInit(): void {
    this.auth.getUsers().subscribe(res => {
      this.auth.users = res
      this.auth.user = this.auth.users[Math.floor(Math.random() * 9)]
      this.user = this.auth.user
      this.feed.myTweets = this.feed.allTweets.filter((tweet) => tweet.user.id === this.auth.user.id)
    })
  }

  editSubmit(editForm: any) {

  }
}