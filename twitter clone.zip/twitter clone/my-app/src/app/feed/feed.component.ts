import { Component, OnInit } from '@angular/core';
import { Comment } from '../model/comment';
import { Tweet } from '../model/tweet';
import { FeedService } from '../services/feed.service';

@Component({
  selector: 'app-feed',
  templateUrl: './feed.component.html',
  styleUrls: ['./feed.component.css']
})
export class FeedComponent implements OnInit {

  newTweet: Tweet
  newComment: Comment

  constructor(public feed: FeedService) {
    this.newTweet = new Tweet()
    this.newComment = new Comment()
  }

  ngOnInit(): void {
  }

  tweetSubmit(tweetForm: any) {
  }

  commentSubmit(commentForm: any) {
  }

}
