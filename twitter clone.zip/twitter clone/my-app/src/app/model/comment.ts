export class Comment {
    id: number
    body: string

    constructor() {
        this.id = 0
        this.body = ''
    }
}