import { User } from "./user"

export class Tweet {

    id: number
    body: string
    likes: number
    comments: number
    user: User

    constructor() {
        this.id = 0
        this.body = ''
        this.likes = 0
        this.comments = 0
        this.user = new User()
    }
}