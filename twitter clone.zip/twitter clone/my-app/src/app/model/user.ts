export class User {
    id: number
    name: string
    bio: string
    picture: string
    email: string
    password: string
    followers: number

    constructor() {
        this.id = 0
        this.name = ''
        this.bio = ''
        this.picture = ''
        this.email = ''
        this.password = ''
        this.followers = 0
    }
}